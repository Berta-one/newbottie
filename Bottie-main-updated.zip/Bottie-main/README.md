# Bottie - Autonomous Crypto Trading Bot

**Bottie** is a full-stack, machine learning-powered crypto trading bot designed to interact with Binance and adapt to market conditions.

---

## 🚀 Features

- ✅ Real-time trading on all Binance pairs (via WebSocket)
- ✅ Machine learning models (LSTM, XGBoost, Transformer-ready)
- ✅ Walk-Forward Optimization (WFO)
- ✅ Authenticated analytics dashboard (Streamlit)
- ✅ Paper trading and live trading support
- ✅ Full Docker + Kubernetes + CI/CD pipeline
- ✅ Monitoring with Prometheus/Grafana
- ✅ Email alerts for system anomalies and trade triggers

---

## 📁 Structure

```
Bottie/
├── engine/                 # Core trading engine (execution, signals, WebSocket)
├── dashboard/              # Streamlit UI
├── models/                 # Pre-trained or training-ready ML models
├── data/                   # Market data & backtesting sets
├── scripts/                # Utility and training scripts
├── docker-compose.yml      # Container orchestration
├── .env.example            # Environment config
└── README.md               # This file
```

---

## ⚙️ Run Locally

```bash
docker-compose up --build
```

> Make sure you rename `.env.example` to `.env` and insert your Binance keys.

---

## 📊 Dashboard

The dashboard (port 8501) includes:
- Trade logs
- Strategy decisions
- Risk metrics
- Real-time performance graphs

---

## 📡 Deployment

Supports VPS or Kubernetes with GitHub Actions-based CI/CD.

---

## ⚠️ Disclaimer

This tool is for educational and research purposes only. Use at your own risk.

---

© 2025 Luigi Rondanini
