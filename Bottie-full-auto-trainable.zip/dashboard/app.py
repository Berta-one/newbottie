import streamlit as st
import pandas as pd
import os

st.set_page_config(page_title="Bottie Dashboard", layout="wide")

st.sidebar.title("Settings")
mode = st.sidebar.selectbox("Trading Mode", ["Paper", "Live"])
strategy = st.sidebar.selectbox("Strategy", ["EMA Crossover", "Momentum", "Ensemble"])

st.title("Bottie AI Trading Dashboard")
st.write(f"**Current Mode:** {mode}")
st.write(f"**Active Strategy:** {strategy}")

if os.path.exists("logs/equity.csv"):
    df = pd.read_csv("logs/equity.csv")
    st.line_chart(df['equity'])
    st.write(df.tail())
else:
    st.warning("Equity log not found.")
