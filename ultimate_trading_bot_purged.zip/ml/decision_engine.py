# Combined LSTM/XGBoost + sentiment logic
