
from qiskit.circuit.library import RealAmplitudes
from qiskit import transpile, QuantumCircuit

def build_ansatz(num_qubits, reps=1):
    return RealAmplitudes(num_qubits=num_qubits, reps=reps, entanglement='full')

def transpile_circuit(circuit, backend):
    return transpile(circuit, backend)

def draw_circuit(circuit):
    return circuit.draw(output='text')
