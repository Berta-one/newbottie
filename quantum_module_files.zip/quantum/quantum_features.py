
import numpy as np
from qiskit.circuit.library import ZZFeatureMap
from qiskit import QuantumCircuit

def encode_features(data, num_qubits):
    """Applies basic angle encoding."""
    qc = QuantumCircuit(num_qubits)
    for i, x in enumerate(data[:num_qubits]):
        qc.ry(x, i)
    return qc

def quantum_fourier_transform(num_qubits):
    qc = QuantumCircuit(num_qubits)
    for i in range(num_qubits):
        qc.h(i)
        for j in range(i+1, num_qubits):
            qc.cu1(np.pi/float(2**(j-i)), j, i)
    for i in range(num_qubits//2):
        qc.swap(i, num_qubits-i-1)
    return qc
