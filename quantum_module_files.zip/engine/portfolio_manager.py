
from quantum.portfolio_optimizer import QuantumPortfolioOptimizer

class HybridPortfolioManager:
    def __init__(self, assets, risk_tolerance=0.1):
        self.assets = assets
        self.quantum_optimizer = QuantumPortfolioOptimizer(len(assets), risk_tolerance)

    def rebalance(self, expected_returns, covariance_matrix):
        return self.quantum_optimizer.optimize(expected_returns, covariance_matrix)
