
from quantum.hybrid_models import HybridQuantumEnsemble
from quantum.fallback_manager import FallbackManager

class QuantumDecisionEngine:
    def __init__(self):
        self.model = HybridQuantumEnsemble()
        self.fallback = FallbackManager()

    def generate_signal(self, X):
        if self.fallback.should_use_quantum():
            try:
                return self.model.predict(X)
            except Exception as e:
                self.fallback.fallback(str(e))
        return self.model.classical_predict(X)
