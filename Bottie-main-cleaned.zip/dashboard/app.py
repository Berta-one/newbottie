import streamlit as st
st.title('Trading Dashboard')
st.write('Dashboard loaded successfully.')
