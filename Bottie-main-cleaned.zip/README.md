# Bottie

This is a full version of the README. All components are implemented.
