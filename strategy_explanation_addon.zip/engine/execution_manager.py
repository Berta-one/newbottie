
from ml.decision_explainer import explain_decision

def log_trade_decision(lstm, xgb, sentiment, signal):
    explanation = explain_decision(lstm, xgb, sentiment, signal)
    for reason in explanation:
        print("📘 Strategy:", reason)
