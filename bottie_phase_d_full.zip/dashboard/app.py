import streamlit as st
import streamlit_authenticator as stauth
import yaml
import pandas as pd
import os

from dashboard.metrics import compute_metrics, calculate_equity_curve
from dashboard.logger_viewer import show_logs

# Auth
with open('dashboard/auth_config.yaml') as file:
    config = yaml.safe_load(file)

authenticator = stauth.Authenticate(
    config['credentials'],
    config['cookie']['name'],
    config['cookie']['key'],
    config['cookie']['expiry_days'],
    config['preauthorized']
)

name, authentication_status, username = authenticator.login("Login", "main")

if authentication_status:
    st.sidebar.success(f"Welcome {name}")
    authenticator.logout("Logout", "sidebar")

    st.title("📊 Bottie Performance Dashboard")

    st.subheader("Portfolio Performance")
    # Simulated data
    trades = pd.DataFrame({
        "timestamp": pd.date_range(start="2023-01-01", periods=100, freq="D"),
        "symbol": ["BTC/USDT"]*100,
        "pnl": np.random.normal(10, 50, 100)
    })
    equity_df = calculate_equity_curve(trades)
    st.line_chart(equity_df.set_index("timestamp")["equity"])

    st.subheader("Performance Metrics")
    metrics = compute_metrics(trades)
    for k, v in metrics.items():
        st.metric(k, f"{v:.2f}")

    st.subheader("Trade History")
    st.dataframe(trades.tail(20))

    show_logs()

else:
    st.error("Please login to access the dashboard.")
