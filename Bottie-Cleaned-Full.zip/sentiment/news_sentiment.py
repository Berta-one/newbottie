def get_sentiment():
    return 0.5