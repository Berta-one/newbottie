def signal_generator(data):
    return 'buy'