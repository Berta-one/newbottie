# Bottie - Clean Trading Bot

Fully implemented trading bot with ML and dashboard.