from engine.trading_core import start_trading

start_trading()