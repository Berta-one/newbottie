def load_ensemble():
    return 'ensemble model loaded'