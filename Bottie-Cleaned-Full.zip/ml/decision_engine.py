def make_decision(data):
    return 'buy'