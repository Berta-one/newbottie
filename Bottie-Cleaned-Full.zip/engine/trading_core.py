def start_trading():
    print('Trading engine started')