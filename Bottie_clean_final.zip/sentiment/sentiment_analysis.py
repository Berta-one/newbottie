# Sentiment analysis logic
