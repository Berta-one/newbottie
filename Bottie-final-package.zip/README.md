# Bottie Final

✅ Production-ready crypto trading bot with:

- Signal generation
- Risk management
- Paper/live trading executor
- Monitoring + CI/CD
- Dashboard and reporting

Run it:
```bash
python run_live.py
```

Deploy with:
```bash
docker-compose up --build
```

Ensure `.env` is properly set for Binance keys.
