# Ultimate AI Trading Bot
This package contains the bot, deployment scripts, CI/CD workflows.
