#!/bin/bash
# One-click VPS installer
