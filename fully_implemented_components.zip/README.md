
# 📈 Fully Working Trading Bot Components

## Contents
- ✅ `app.py`: Streamlit dashboard with real chart
- ✅ `main.py`: Launch script
- ✅ `historical_data.csv`: Sample price feed
- ✅ `ema_crossover.py`: A functioning EMA strategy

## How to Use
Upload these into Replit or run on your machine with:
```bash
pip install streamlit pandas matplotlib
python main.py
```
