
#!/bin/bash
echo "Setting up AI Trading Bot environment..."
apt-get update && apt-get install -y docker docker-compose
docker-compose up -d --build
