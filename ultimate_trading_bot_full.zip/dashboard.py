
import streamlit as st

st.title("AI Trading Bot Dashboard")
st.write("Monitor live trades, account status, and performance.")
