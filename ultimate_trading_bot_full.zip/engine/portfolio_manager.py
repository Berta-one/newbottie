
import ccxt
import os

API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")

def calculate_order_size(price, pct):
    exchange = ccxt.binance({
        'apiKey': API_KEY,
        'secret': API_SECRET
    })
    balance = exchange.fetch_balance()
    usdt = balance['total']['USDT']
    return round((usdt * pct) / price, 6)
