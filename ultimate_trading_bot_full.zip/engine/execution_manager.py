
import ccxt
import os

API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")

def execute_order(signal, size, symbol, mode):
    exchange = ccxt.binance({
        'apiKey': API_KEY,
        'secret': API_SECRET
    })
    print(f"Executing {signal} order: {size} {symbol} in {mode} mode")
    if mode == 'live':
        if signal == 'BUY':
            exchange.create_market_buy_order(symbol.upper(), size)
        elif signal == 'SELL':
            exchange.create_market_sell_order(symbol.upper(), size)
    else:
        print("Paper trading mode: no real order executed")
