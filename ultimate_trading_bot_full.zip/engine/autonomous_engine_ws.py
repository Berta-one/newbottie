
import asyncio
import json
import ccxt
import os
import websockets
from engine.execution_manager import execute_order
from engine.portfolio_manager import calculate_order_size
from ml.decision_engine import get_trade_signal

API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
MODE = os.getenv("MODE", "live")

symbol = "btcusdt"
quantity_pct = float(os.getenv("MAX_POSITION_SIZE", 0.05))

async def binance_ws():
    url = f"wss://stream.binance.com:9443/ws/{symbol}@ticker"
    async with websockets.connect(url) as ws:
        print(f"Connected to Binance WebSocket for {symbol}")
        async for message in ws:
            data = json.loads(message)
            price = float(data['c'])
            signal = get_trade_signal(price)
            if signal in ['BUY', 'SELL']:
                size = calculate_order_size(price, quantity_pct)
                execute_order(signal, size, symbol, MODE)

asyncio.run(binance_ws())
