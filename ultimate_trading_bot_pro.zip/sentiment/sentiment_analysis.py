
def get_sentiment_score(pair):
    # Dummy sentiment logic: real API can replace this
    return 0.5
