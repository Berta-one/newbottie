# Ultimate AI Trading Bot (Live Binance)
This bot uses pre-trained AI models (LSTM, XGBoost) + sentiment for multi-pair trading.
