
import numpy as np
from tensorflow.keras.models import load_model
import joblib
from sentiment.sentiment_analysis import get_sentiment_score
from ml.model_loader import download_models

download_models()
lstm_model = load_model('models/lstm_model.h5')
xgb_model = joblib.load('models/xgboost_model.json')

def get_trade_signal(pair, price):
    sentiment = get_sentiment_score(pair)
    X = np.array([[price, sentiment]])
    lstm_pred = lstm_model.predict(X)[0][0]
    xgb_pred = xgb_model.predict(X)[0]
    score = (0.5*lstm_pred + 0.3*xgb_pred + 0.2*sentiment)
    if score > 0.6:
        return 'BUY'
    elif score < 0.4:
        return 'SELL'
    return None
