
import os, requests

def get_sentiment_score(pair):
    key = os.getenv('NEWS_API_KEY')
    if key:
        try:
            r = requests.get(f'https://newsapi.org/v2/everything?q={pair}&apiKey={key}')
            articles = r.json().get('articles', [])
            return min(1.0, len(articles)/50)
        except:
            return 0.5
    return 0.5
