# Ultimate AI Trading Bot (Live)
## Features:
- Multi-pair Binance trading (BTC, ETH, BNB)
- AI models (LSTM + XGBoost + Sentiment)
- Streamlit dashboard
- Docker deployment

## How to Run:
1. Fill `.env` with your Binance keys
2. `docker-compose up -d --build`
