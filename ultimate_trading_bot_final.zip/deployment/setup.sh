
#!/bin/bash
echo "Installing Docker and starting bot..."
apt-get update && apt-get install -y docker docker-compose
docker-compose up -d --build
