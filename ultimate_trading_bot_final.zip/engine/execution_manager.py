
import ccxt, os, time

API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")

def execute_order(signal, size, symbol, mode):
    try:
        exchange = ccxt.binance({'apiKey': API_KEY, 'secret': API_SECRET})
        print(f"Executing {signal} {symbol.upper()} size {size} ({mode})")
        if mode == 'live':
            if signal == 'BUY':
                exchange.create_market_buy_order(symbol.upper(), size)
            elif signal == 'SELL':
                exchange.create_market_sell_order(symbol.upper(), size)
        else:
            print("Paper mode: simulated execution")
    except Exception as e:
        print(f"Order failed: {e}")
        time.sleep(1)
