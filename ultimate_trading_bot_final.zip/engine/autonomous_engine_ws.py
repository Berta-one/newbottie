
import asyncio, json, os, websockets
from engine.execution_manager import execute_order
from engine.portfolio_manager import calculate_order_size
from ml.decision_engine import get_trade_signal

MODE = os.getenv("MODE", "live")
PAIRS = ["btcusdt", "ethusdt", "bnbusdt"]
quantity_pct = float(os.getenv("MAX_POSITION_SIZE", 0.05))

async def subscribe(pair):
    url = f"wss://stream.binance.com:9443/ws/{pair}@ticker"
    async with websockets.connect(url) as ws:
        print(f"Subscribed to {pair}")
        async for msg in ws:
            data = json.loads(msg)
            price = float(data['c'])
            signal = get_trade_signal(pair, price)
            if signal in ['BUY', 'SELL']:
                size = calculate_order_size(pair, price, quantity_pct)
                execute_order(signal, size, pair, MODE)

async def main():
    await asyncio.gather(*(subscribe(p) for p in PAIRS))

asyncio.run(main())
