
import streamlit as st
import pandas as pd
import os

st.title("AI Trading Bot Dashboard")
st.subheader("Mode: " + os.getenv("MODE", "live"))
st.write("Connected pairs: BTC/USDT, ETH/USDT, BNB/USDT")

st.line_chart(pd.DataFrame({'BTC': [30000, 30100], 'ETH': [2000, 2020]}))
st.text("Trade log will be displayed here")
