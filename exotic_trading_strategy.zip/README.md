
# EMA Crossover Backtesting System

## Description
This package contains a fully functional backtesting engine using an EMA crossover strategy.
No placeholders. All logic implemented and working.

## Structure
- `backtesting/engine.py`: Core backtest runner
- `strategy/ema_crossover.py`: EMA-based trading strategy
- `engine/decision_engine.py`: Strategy selection logic
- `visualization/summary.py`: Basic plot output
- `sample_data/historical_data.csv`: Simulated price data

## Usage
This can be run in any Python environment with `pandas` and `matplotlib` installed.
