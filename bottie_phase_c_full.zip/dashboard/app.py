import streamlit as st
import streamlit_authenticator as stauth
import yaml
import pandas as pd
import os
from engine.trading_core import TradingCore
from engine.portfolio_manager import PortfolioManager

# Load authentication
with open('dashboard/auth_config.yaml') as file:
    config = yaml.safe_load(file)

authenticator = stauth.Authenticate(
    config['credentials'],
    config['cookie']['name'],
    config['cookie']['key'],
    config['cookie']['expiry_days'],
    config['preauthorized']
)

name, authentication_status, username = authenticator.login("Login", "main")

if authentication_status:
    st.sidebar.success(f"Welcome {name}")
    authenticator.logout("Logout", "sidebar")

    st.title("📈 Bottie Trading Dashboard")
    st.subheader("Live Portfolio Metrics")
    st.write("Sample Portfolio Value: $100,000")

    st.subheader("Latest Trade Signals")
    trade_df = pd.DataFrame([
        {"Symbol": "BTC/USDT", "Signal": "Buy", "Confidence": 0.87},
        {"Symbol": "ETH/USDT", "Signal": "Sell", "Confidence": 0.65}
    ])
    st.dataframe(trade_df)

    st.subheader("Controls")
    if st.button("Toggle Paper/Live Mode"):
        st.write("Switched mode (mock)")
else:
    st.error("Please login to access the dashboard.")
