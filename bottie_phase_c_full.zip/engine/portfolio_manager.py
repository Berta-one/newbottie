class PortfolioManager:
    def __init__(self, capital=100000):
        self.capital = capital
        self.positions = {}

    def allocate(self, symbol, confidence):
        if confidence > 0.8:
            allocation = self.capital * 0.1
        else:
            allocation = self.capital * 0.05
        self.positions[symbol] = allocation
        return allocation

    def update(self, symbol, pnl):
        self.capital += pnl
