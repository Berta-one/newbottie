class PortfolioManager:
    def __init__(self, capital=10000):
        self.capital = capital
        self.positions = {}

    def allocate(self, symbol, confidence):
        position_size = self.capital * min(confidence, 1.0)
        self.positions[symbol] = position_size
        return position_size

    def update_capital(self, pnl):
        self.capital += pnl
